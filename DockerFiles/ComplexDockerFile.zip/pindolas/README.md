Build

sudo docker build -t "NAME" -f "PATH" .

ex.
	sudo docker build -t ngnxx -f ~/ngnx/ .

List Docker Images

sudo docker images

Run

sudo docker run -d -p 8080:80 "NAME"

ex.
	sudo docker run -d -p 8080:80 ngnxx

List Running Containers

sudo docker ps
